import React from "react";

export default function Welcome(props){
    return <h1>안녕, {props.name}</h1>
}